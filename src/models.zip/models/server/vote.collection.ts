import { Permission, Role, DatabasesIndexType, OrderBy } from "node-appwrite";

import { db, voteCollection } from "../name";

import { databases } from "./config";

async function waitForAttributes(dbId: string, collectionId: string) {
  while (true) {
    const { attributes } = await databases.listAttributes(dbId, collectionId);
    const allReady = attributes.every(
      (attr: any) => attr.status === "available",
    );

    if (allReady) break;
    await new Promise((res) => setTimeout(res, 1000));
  }
}

export default async function createVoteCollection() {
  await databases.createCollection(db, voteCollection, voteCollection, [
    Permission.create(Role.users()),
    Permission.read(Role.any()),
    Permission.read(Role.users()),
    Permission.update(Role.users()),
    Permission.delete(Role.users()),
  ]);

  console.log("Vote collection created successfully");

  // create attributes

  await Promise.all([
    databases.createEnumAttribute(
      db,
      voteCollection,
      "type",
      ["question", "answer"],
      true,
    ),
    databases.createStringAttribute(db, voteCollection, "typeId", 50, true),
    databases.createEnumAttribute(
      db,
      voteCollection,
      "voteStatus",
      ["upvote", "downvote"],
      true,
    ),
    databases.createStringAttribute(db, voteCollection, "votedById", 50, true),
  ]);

  console.log("Vote Attributes created, waiting for availability...");

  await waitForAttributes(db, voteCollection);

  await Promise.all([
    databases.createIndex(
      db,
      voteCollection,
      "typeId",
      DatabasesIndexType.Key,
      ["typeId"],
      [OrderBy.Asc],
    ),
    databases.createIndex(
      db,
      voteCollection,
      "type",
      DatabasesIndexType.Key,
      ["type"],
      [OrderBy.Asc],
    ),
    databases.createIndex(
      db,
      voteCollection,
      "voteStatus",
      DatabasesIndexType.Key,
      ["voteStatus"],
      [OrderBy.Asc],
    ),
  ]);
}
