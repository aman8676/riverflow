import {DatabasesIndexType, Permission, Role,OrderBy} from "node-appwrite";

import {answerCollection, db} from "../name";

import {databases} from "./config";

async function waitForAttributes(dbId: string, collectionId: string) {
    while(true){
        const {attributes} = await databases.listAttributes(dbId, collectionId);
        const allReady = attributes.every((attr:any)=>attr.status ==="available")

        if(allReady) break;

        await new Promise((res)=>setTimeout(res,1000));
    }
}

export default async function createAnswerCollection() {

    await databases.createCollection(db, answerCollection, answerCollection, [
        Permission.create(Role.users()),
        Permission.read(Role.any()),
        Permission.read(Role.users()),
        Permission.update(Role.users()),
        Permission.delete(Role.users())
    ]);

    console.log("Answer collection created successfully");

    //create attribute 

    await Promise.all([
        databases.createStringAttribute(db,answerCollection,"content",10000,true),
        databases.createStringAttribute(db,answerCollection,"questionId",50,true),
        databases.createStringAttribute
        (db,answerCollection,"authorId",50,true)
    ]);

     console.log(" Answer Attributes created, waiting for availability...");
    
      await waitForAttributes(db, answerCollection);

      await Promise.all([
        databases.createIndex(
            db,
            answerCollection,
            "content",
            DatabasesIndexType.Fulltext,
            ["content"],
            [OrderBy.Asc]
        ),
            databases.createIndex(
        db,answerCollection,
        "questionId",
        DatabasesIndexType.Key,
        ["questionId"],
        [OrderBy.Asc]
            ),

            databases.createIndex(
        db,answerCollection,
        "authorId",
        DatabasesIndexType.Key,
        ["authorId"],
        [OrderBy.Asc]
            )
      ])

        console.log("Indexes created successfully");




}